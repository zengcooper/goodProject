﻿//程序集
using System.Collections.Generic;
using System.Linq;

//NuGet
//NuGet-----EntityFramework
using System.Data.Entity;

//项目

namespace Data
{
    /// <summary>
    /// 【动态实体的仓储--类】
    /// <typeparam name="TEntity">动态的实体类型。</typeparam>
    /// <remarks>
    ///     将内存中指定类型的实体实例，通过方法调用EF上下文实例注册该实体实例的状态。
    /// </remarks>
    /// </summary>
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        #region 构造方法
        /// <summary>
        /// 【拷贝构造方法】
        /// <param name="eFContext">EntityFramework数据库访问上下文实例。</param>
        /// <remarks>
        /// 摘要：
        ///    对该类中的一些对象的实例，进行初始化操作。
        /// </remarks> 
        /// </summary>
        public Repository(EFContext eFContext)
        {
            _eFContextRepository = eFContext;
        }
        #endregion

        #region 变量--私有/保护
        /// <summary>
        /// 【EF上下文实例】
        /// <remarks>
        /// 摘要：
        ///    该变量只被声明，并未被立即初始化，它的初始化操作在拷贝构造方法中。
        /// </remarks> 
        /// </summary>
        private EFContext _eFContextRepository;
        #endregion

        #region 方法
        /// <summary>
        /// 【注册新建】
        /// <param name="entity">一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     将内存中一个指定类型的实体实例，通过EF上下文实例将该实体实例被注册为新建状态。
        /// </remarks> 
        /// </summary>
        public void RegisterCreate(TEntity entity)
        {
            if (_eFContextRepository.Entry(entity).State == EntityState.Detached)
                _eFContextRepository.Entry(entity).State = EntityState.Added;
        }

        /// <summary>
        /// 【注册新建】
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///     将实体实例集合中的每个实例，通过EF上下文实例将这些实体实例逐一的被注册为新建状态。
        /// </remarks> 
        /// </summary>
        public void RegisterCreate(IEnumerable<TEntity> entityEnumerable)
        {
            try
            {
                _eFContextRepository.Configuration.AutoDetectChangesEnabled = false;
                foreach (TEntity entity in entityEnumerable)
                {
                    RegisterCreate(entity);
                }
            }
            finally
            {
                _eFContextRepository.Configuration.AutoDetectChangesEnabled = true;
            }
        }

        /// <summary>
        /// 【注册更新】
        /// <param name="oldEntity">更新前的，一个指定类型的实体实例。</param>
        /// <param name="newEntity">将要被更新的，一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     本方法实际上执行的是比较更新前与将要被更新实体实例中的数据异同，如果两者有不同的数据，
        /// 更新前实体实例中的数据替换为被更新实体实例中的数据，同时将数据更新后的更新前实体实例被注册为更新状态。
        /// </remarks> 
        /// </summary>
        public void RegisterUpdate(TEntity oldEntity, TEntity newEntity)
        {
            if (_eFContextRepository.Entry<TEntity>(newEntity).State == EntityState.Detached)
            {
                //  使用下行语句，对实体/聚合实例时行更新，如果使用“ SetRepository.Attach(entity);
                //_eFContextRepository.Entry<TEntity>(entity).State = EntityState.Modified;”
                //会出现：“因为相同类型的其他实体已具有相同的主键值。在使用 "Attach" 
                //方法或者将实体的状态设置为 "Unchanged" 或 "Modified" 时如果图形中的任何实体具有冲突键值，
                //则可能会发生上述行为”异常，导致数据无数更新
                _eFContextRepository.Entry<TEntity>(oldEntity).CurrentValues.SetValues(newEntity);
            }
        }

        /// <summary>
        /// 【注册更新】
        /// <param name="oldEntityEnumerable">更新前的，一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <param name="newEntityEnumerable">>将要被更新的，一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///    将实体实例集合中的每个实例逐一比较更新前与将要被更新实体实例中的数据异同，如果两者有不同的数据，
        /// 更新前实体实例中的数据替换为被更新实体实例中的数据，同时将数据更新后的更新前实体实例逐一被注册为更新状态。
        /// </remarks> 
        /// </summary>
        public void RegisterUpdate(IEnumerable<TEntity> oldEntityEnumerable, IEnumerable<TEntity> newEntityEnumerable)
        {
            try
            {
                _eFContextRepository.Configuration.AutoDetectChangesEnabled = false;
                for (int i = 0; i < newEntityEnumerable.Count(); i++)
                {
                    TEntity _oldEntity = oldEntityEnumerable.ElementAt(i);
                    TEntity _newEntity = newEntityEnumerable.ElementAt(i);
                    RegisterUpdate(_oldEntity, _newEntity);
                }
            }
            finally
            {
                _eFContextRepository.Configuration.AutoDetectChangesEnabled = true;
            }
        }

        /// <summary>
        /// 【注册更新】
        /// <param name="entity">一个/多个属性所对应的数据被更新后的实体实例。</param>
        /// <param name="propertyArray">
        ///     将要被更新的，指定实体的一个/多个属性（此属性必须与数据库表中有相对应存在的字段）集合的字符串集合数组实例。
        /// </param>
        /// <remarks>
        /// 摘要：
        ///     通过一个指定类型的实体实例在一个/多个属性所对应的数据被更新后，此时实体实例的这些属性例逐一被注册为更新状态。
        /// </remarks> 
        /// </summary>
        public void RegisterUpdate(TEntity entity, string[] propertyArray)
        {
            _eFContextRepository.Set<TEntity>().Attach(entity);
            foreach (var item in propertyArray)
            {
                _eFContextRepository.Entry(entity).Property(item).IsModified = true;
            }
        }

        /// <summary>
        /// 【注册更新】
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <param name="propertyArray">
        ///     将要被更新的，指定实体的一个/多个属性（此属性必须与数据库表中有相对应存在的字段）集合的字符串集合数组实例。
        /// </param>
        /// <remarks>
        /// 摘要：
        ///     将实体实例集合中的每个实例在一个/多个属性所对应的数据被更新后，此时逐一的将这些实体实例的这些属性逐一被注册为更新状态。
        /// </remarks> 
        /// </summary>
        public void RegisterUpdate(IEnumerable<TEntity> entityEnumerable, string[] propertyArray)
        {
            try
            {
                _eFContextRepository.Configuration.AutoDetectChangesEnabled = false;
                foreach (TEntity entity in entityEnumerable)
                {
                    RegisterUpdate(entity, propertyArray);
                }
            }
            finally
            {
                _eFContextRepository.Configuration.AutoDetectChangesEnabled = true;
            }
        }

        /// <summary>
        /// 【删除状态】
        /// <param name="entity">一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     将内存中一个指定类型的实体实例，通过EF上下文实例将该实体实例被注册为删除状态。
        /// </remarks> 
        /// </summary>
        public void RegisterDeleted(TEntity entity)
        {
            _eFContextRepository.Entry<TEntity>(entity).State = EntityState.Deleted;
        }

        /// <summary>
        /// 【删除状态】
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///     将实体实例集合中的每个实例，通过EF上下文实例将这些实体实例逐一的被注册为删除状态。
        /// </remarks> 
        /// </summary>
        public void RegisterDeleted(IEnumerable<TEntity> entityEnumerable)
        {
            try
            {
                _eFContextRepository.Configuration.AutoDetectChangesEnabled = false;
                foreach (TEntity entity in entityEnumerable)
                {
                    RegisterDeleted(entity);
                }
            }
            finally
            {
                _eFContextRepository.Configuration.AutoDetectChangesEnabled = true;
            }
        }
        #endregion
    }
}
