﻿//程序集
using System;
using System.Linq;
using System.Collections.Generic;

//NuGet
//NuGet-----EntityFramework
using System.Data.Entity;

//项目

namespace Data
{
    /// <summary>
    /// 【工作单元--类】
    /// <remarks>
    /// 摘要：
    ///    工作单元（UnitOfWork）模式： 
    ///    1、主要的作用将EF上下文实例所注册状态后的一个/多个实体实例同时持久到数据库中。
    ///    2、在提交数据时如果有一条/多条数据未能提交成功则执行回滚操作。
    ///    3、减少对数据库的调用次数，多而提高性能。
    ///    4、要确保销毁和释放EF上下文实例，来确保EF上下文实例使用完后被显式地销毁。
    ///     因为IUnitOfWork接口继承自IDisposable接口，所以不再对IDisposable接口中的Dispose()方法再一次进行声明，
    /// 只在UnitOfWork类中对IDisposable接口中的Dispose()方法进行定义和实现。
    /// </remarks>
    /// </summary>
    public class UnitOfWork : IUnitOfWork
    {
        #region 构造方法
        /// <summary>
        /// 【拷贝构造方法】
        /// <param name="eFContext">EntityFramework数据库访问上下文实例。</param>
        /// <remarks>
        /// 摘要：
        ///    对该类中的一些对象的实例，进行初始化操作。
        /// </remarks> 
        /// </summary>
        public UnitOfWork(EFContext eFContext)
        {
            _eFContextUnitOfWork = eFContext;
            _repositorieDictionary = new Dictionary<Type, object>();
        }
        #endregion

        #region 属性--私有/保护--数据库事务
        /// <summary>
        /// 【提交成功？】
        /// <remarks>
        /// 摘要：
        ///    获取/设置一个值，该值指示一条/多条数据是否已经成功提交到相应的数据库中，
        /// 默认值--false；未成功提交--flase；成功提交--ture。
        /// </remarks>
        /// </summary>
        protected bool IsCommitted { get; private set; }
        #endregion

        #region 变量--私有/保护
        /// <summary>
        /// 【EF上下文实例】
        /// <remarks>
        /// 摘要：
        ///    该变量只被声明，并未被立即初始化，它的初始化操作在拷贝构造方法中。
        /// </remarks> 
        /// </summary>
        private EFContext _eFContextUnitOfWork;

        /// <summary>
        /// 【仓储字典实例】
        /// <remarks>
        /// 摘要：
        ///    该变量只被声明，并未被立即初始化，它的初始化操作在拷贝构造方法中。
        ///    仓储字典实例的主要目的是为了防止重复的实例化已经存在的仓储实例，
        /// 在调用GetRepository方法时如果仓储字典实例中有指定实体实例时，则返回该实体的仓储实例，
        /// 没有指定实体实例时，实例化在该仓储实例，并在仓储字典实例添加它。
        /// </remarks> 
        /// </summary>
        private Dictionary<Type, object> _repositorieDictionary;
        #endregion


        #region 方法--接口实现--数据库操作
        /// <summary>
        /// 【设置】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <returns>
        /// 返回：
        ///     返回，获取一个指定实体类型的IQueryable实例。
        /// </returns>
        /// <remarks>
        /// 摘要：
        ///    IQueryable返回的是查询表达式，即是把Skip， Where,take 这些方法表达式的操作翻译成相应的T-SQL语句，
        /// 也就是说生成了SQL查询语句但是却还没有与数据库进行交互。
        /// 如想要获取指定实体所对应的数据库表中的所有的数据集，需要在该方法后添加：“.ToList()”。
        /// IQueryable，IEnumerable的区别：
        ///     IEnumerable<T> 泛型类在调用自己的SKip 和 Take 等扩展方法之前数据就已经加载在本地内存里了，
        ///  而IQueryable<T> 是将Skip， Where,take 这些方法表达式翻译成T-SQL语句之后再向SQL服务器发送命令，
        ///  也是延迟在我要真正显示数据的时候才执行。
        /// </remarks> 
        /// </summary>
        public IQueryable<TEntity> Set<TEntity>() where TEntity : class
        {
            return _eFContextUnitOfWork.Set<TEntity>();
        }

        /// <summary>
        /// 【获取所有】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <returns>
        /// 返回：
        ///     返回，获取一个指定实体类型的IQueryable实例。
        /// </returns>
        /// <remarks>
        /// 摘要：
        ///    此方法主要通过一个指定实体类型实例从数据库中相应的表中获取所有的数据行，
        ///  该方法只能用于数据查询后的显示操作，不能在使用此方法获取指定实例后，再执行更新等操作，否则会产生异常。
        ///     IQueryable返回的是查询表达式，即是把Skip， Where,take 这些方法表达式的操作翻译成相应的T-SQL语句，
        /// 也就是说生成了SQL查询语句但是却还没有与数据库进行交互。
        /// 如想要获取指定实体所对应的数据库表中的所有的数据集，需要在该方法后添加：“.ToList()”。
        /// </remarks> 
        /// </summary>
        public IQueryable<TEntity> GetAll<TEntity>() where TEntity : class
        {
            /*如果使用Set<TEntity>()方法后添加.AsNoTracking()方法获取一个指定的实体实例后，
             再执行更新等操作在“_eFContextRepository.Entry<TEntity>(oldEntity).CurrentValues.SetValues(newEntity);”语句时会出现异常：
             “Member 'CurrentValues' cannot be called for the entity of type 'TeacherGroup' because the entity does not exist in the context. 
             To add an entity to the context call the Add or Attach method of DbSet<TeacherGroup>.”
             所以如果想要获取一个定实例后，再执行更新等操作必须使用方法：“public IQueryable<TEntity> Set<TEntity>() where TEntity : class”*/
            return Set<TEntity>().AsNoTracking();
        }

        /// <summary>
        /// 【插入】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entity">一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     先将一个指定类型的实体实例先注册为新建状态后，将其提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        public void Insert<TEntity>(TEntity entity) where TEntity : class
        {
            IRepository<TEntity> _repository = GetRepository<TEntity>();
            _repository.RegisterCreate(entity);
            IsCommitted = false;
            Commit();
        }

        /// <summary>
        /// 【插入】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///     先将指定类型的实体实例集合中的每个实例先注册为新建状态后，将实体实例集合同时提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        public void Insert<TEntity>(IEnumerable<TEntity> entityEnumerable) where TEntity : class
        {
            IRepository<TEntity> _repository = GetRepository<TEntity>();
            _repository.RegisterCreate(entityEnumerable);
            IsCommitted = false;
            Commit();
        }

        /// <summary>
        /// 【更新】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="oldEntity">更新前的，一个指定类型的实体实例。</param>
        /// <param name="newEntity">将要被更新的，一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     先比较更新前与将要被更新一个指定类型的实体实例中的数据异同，如果两者有不同的数据，
        /// 更新前实体实例中的数据替换为被更新实体实例中的数据，同时将数据更新后的更新前实体实例被注册为更新状态后，
        /// 将其提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        public void Update<TEntity>(TEntity oldEntity, TEntity newEntity) where TEntity : class
        {
            IRepository<TEntity> _repository = GetRepository<TEntity>();
            _repository.RegisterUpdate(oldEntity, newEntity);
            IsCommitted = false;
            Commit();
        }

        /// <summary>
        /// 【更新】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="oldEntityEnumerable">更新前的，一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <param name="newEntityEnumerable">>将要被更新的，一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///    先将实体实例集合中的每个实例逐一比较更新前与将要被更新实体实例中的数据异同，如果两者有不同的数据，
        /// 更新前实体实例中的数据替换为被更新实体实例中的数据，同时将数据更新后的更新前实体实例逐一被注册为更新状态后，
        /// 将数据更新后的更新前实体实例集合同时提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        public void Update<TEntity>(IEnumerable<TEntity> oldEntityEnumerable, IEnumerable<TEntity> newEntityEnumerable) where TEntity : class
        {
            IRepository<TEntity> _repository = GetRepository<TEntity>();
            _repository.RegisterUpdate(oldEntityEnumerable, newEntityEnumerable);
            IsCommitted = false;
            Commit();
        }

        /// <summary>
        /// 【更新】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entity">一个/多个属性所对应的数据被更新后的实体实例。</param>
        /// <param name="propertyArray">
        ///     将要被更新的，指定实体的一个/多个属性（此属性必须与数据库表中有相对应存在的字段）集合的字符串集合数组实例。
        /// </param>
        /// <remarks>
        /// 摘要：
        ///     先将一个指定类型的实体实例在一个/多个属性所对应的数据被更新后，此时实体实例的这些属性例逐一被注册为更新状态后，
        /// 将此时实体实例提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        public void Update<TEntity>(TEntity entity, string[] propertyArray) where TEntity : class
        {
            IRepository<TEntity> _repository = GetRepository<TEntity>();
            _repository.RegisterUpdate(entity, propertyArray);
            IsCommitted = false;
            Commit();
        }

        /// <summary>
        /// 【更新】
        ///  <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <param name="propertyArray">
        ///     将要被更新的，指定实体的一个/多个属性（此属性必须与数据库表中有相对应存在的字段）集合的字符串集合数组实例。
        /// </param>
        /// <remarks>
        /// 摘要：
        ///      先将实体实例集合中的每个实例在一个/多个属性所对应的数据被更新后，此时逐一的将这些实体实例的这些属性逐一被注册为更新状态后，
        /// 将数据更新后的更新前实体实例集合同时提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        public void Update<TEntity>(IEnumerable<TEntity> entityEnumerable, string[] propertyArray) where TEntity : class
        {
            IRepository<TEntity> _repository = GetRepository<TEntity>();
            _repository.RegisterUpdate(entityEnumerable, propertyArray);
            IsCommitted = false;
            Commit();
        }

        /// <summary>
        /// 【删除】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entity">一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     先将一个指定类型的实体实例先注册为删除状态后，将其提交并从数据表中删除实体实例所对应的行。
        /// </remarks> 
        /// </summary>
        public void Delete<TEntity>(TEntity entity) where TEntity : class
        {
            IRepository<TEntity> _repository = GetRepository<TEntity>();
            _repository.RegisterDeleted(entity);
            IsCommitted = false;
            Commit();
        }

        /// <summary>
        /// 【删除】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///     先将指定类型的实体实例集合中的每个实例先注册为删除状态后，
        ///  将实体实例集合同时提交并从数据表中删除实体实例所对应的一行/多行。
        /// </remarks> 
        /// </summary>
        public void Delete<TEntity>(IEnumerable<TEntity> entityEnumerable) where TEntity : class
        {
            IRepository<TEntity> _repository = GetRepository<TEntity>();
            _repository.RegisterDeleted(entityEnumerable);
            IsCommitted = false;
            Commit();
        }
        #endregion

        #region 方法--IDisposable成员实现
        /// <summary>
        /// 【销毁？】
        /// </summary>
        /// <remarks>
        ///     用来确认对象已经被销毁。
        ///     默认值：flase；flase：未被销毁，ture：已经被销毁。
        /// </remarks> 
        /// <returns>无返回</returns>
        private bool _isDisposed = false;

        /// <summary>
        /// 【释放】
        /// <param name="isDisposing">
        ///     指示是否是否正在执行销毁操作，默认值--ture；不执行--flase；正在执行--ture。
        /// </param>
        /// <remarks>
        /// 摘要：
        ///      确保EF上下文实例使用完后被显式地释放。
        /// </remarks> 
        /// </summary>
        protected virtual void Dispose(bool isDisposing)
        {
            if (!_isDisposed)
            {
                if (isDisposing)
                {
                    if (!IsCommitted)
                    {
                        Commit();
                    }
                    _eFContextUnitOfWork.Dispose();
                    _eFContextUnitOfWork = null;
                }
            }
            _isDisposed = true;
        }

        /// <summary>
        /// 【释放】
        /// <remarks>
        /// 摘要：
        ///     如果执行了一个实例的的该方法，说明实例已经可以释放所分配的内存了，
        /// 但如果没有执行“实例 = null”语句（例:  _eFContextUnitOfWork = null;）或没有已经执行过 GC.SuppressFinalize(this);语句，
        /// 如果该实例中存在数据，则实例的所有数据依然存在于内存中。如果实例的值为null或已经执行过 GC.SuppressFinalize(this);语句，
        /// 则实例在内存中已经不存在数据，说明实例已经成功的释放所分配的内存。
        ///     释放单元操作中的DBContext实例对象或继承于DBContext的实例对象（这时指EFContext）, 
        /// 同时关闭数据库连接,确保调用所指定的动态模型类对象及时销毁和内存的释放，只有该方法是IDisposable成员接口的实现。
        /// 托管资源：
        ///     由CLR管理分配和释放的资源，即由CLR里new出来的对象，针对托管资源，DotNet的垃圾回收器会自动地回收托管资源。
        /// 非托管资源：
        ///     不受CLR管理的对象，windows内核对象，如文件、数据库连接、套接字、COM对象等，则需要用自定义的Dispose方法显式释放非托管资源。
        /// </remarks> 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            //如果一个实例已经调用了其Dispose方法，那么就释放该实例分配的内存。
            GC.SuppressFinalize(this);
        }
        #endregion

        #region 方法--私有/保护
        /// <summary>
        /// 【获取仓储】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <remarks>
        /// 摘要：
        ///     获取一个指定类型实体的仓储实例，同时该方法防止重复的实例化已经存在的仓储实例，
        ///     如果仓储字典实例中有指定实体实例时，则返回该实体的仓储实例，
        /// 没有指定实体实例时，实例化在该仓储实例，并在仓储字典实例添加它。
        /// </remarks> 
        /// </summary>
        protected IRepository<TEntity> GetRepository<TEntity>() where TEntity : class
        {
            if (_repositorieDictionary.Keys.Contains(typeof(TEntity)))
                return _repositorieDictionary[typeof(TEntity)] as Repository<TEntity>;
            var repository = new Repository<TEntity>(_eFContextUnitOfWork);
            _repositorieDictionary.Add(typeof(TEntity), repository);
            return repository;
        }
        #endregion

        #region 方法--私有/保护--数据库事务
        /// <summary>
        /// 【提交】
        ///<returns>
        /// 返回：
        ///     返回，如果一条/多条数据是否已经成功提交到相应的数据库中，则返回已经提交完成的数据的行数，否则通过异常操作执行回滚操作。
        /// </returns>
        /// <remarks>
        /// 摘要：
        ///     把仓储已经注册的操作（删除、添加、更新）中的一条/多条数据，同时提交到相应的数据库中,这里的重点即是：同时提交。
        ///  工作单元只所以被提出主要的意义和作用就是为了同时成功提交条数据（这是通过注册操作来实现的），
        ///  如果在提交过程中出现意外或提交未成功则通过异常操作执行回滚操作，所以提交操作是工作单元操作重心，
        ///  在该声明中其它的所有操作都是为此操作提供支持的。
        /// </remarks> 
        /// </summary>
        protected long Commit()
        {
            if (IsCommitted)
            {
                return 0;
            }
            try
            {
                long _result = _eFContextUnitOfWork.SaveChanges();
                IsCommitted = true;
                return _result;
            }
            catch (Exception)
            {
                Rollback();
                throw;
            }
        }

        /// <summary>
        /// 【回滚】
        /// <remarks>
        /// 摘要：
        ///     如果仓储已经注册的操作（删除、添加、更新）中的一条/多条数据，在提交过程中出现意外或提交未成功则通过异常操作执行回滚操作。
        /// </remarks> 
        /// </summary>
        protected void Rollback()
        {
            IsCommitted = false;
        }
        #endregion

    }
}
