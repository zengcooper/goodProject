﻿//程序集

//NuGet
//NuGet-----EntityFramework
using System.Data.Entity;

//项目

namespace Data
{
    /// <summary>
    /// 【数据库上下文--接口】
    /// <remarks>
    /// 摘要：
    ///    表示数据库上下文接口。
    /// </remarks>
    /// </summary>
    public partial interface IDBContext
    {
    }
}
