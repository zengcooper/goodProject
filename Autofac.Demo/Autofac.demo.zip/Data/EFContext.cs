﻿//默认引用

//声明引用
//程序集
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

//NuGet
//NuGet-----EntityFramework
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

//项目
using Data.Mapping;

namespace Data
{
    /// <summary>
    /// 【基于EF的数据库上下文--类】
    /// <remarks>
    /// 摘要：
    ///    表示基于EF的数据库上下文类。
    /// </remarks>
    /// </summary>
    public class EFContext : DbContext, IDBContext
    {
        #region 构造方法
        public EFContext() : base()
        {
        }
        #endregion

        #region 属性
        #endregion

        #region 方法--重写
        /// <summary>
        /// 【模型创建】
        /// <param name="modelBuilder">模型生成器实例。</param> 
        /// <remarks>
        /// 摘要：
        ///     OnModelCreating方法可以被用来重载与定制规定我们的模型类如何与我们的数据表进行映射的映射规则。
        /// </remarks> 
        /// </summary>
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //移除复数表名的契约,即实体类与数据库表名的单复数形式相同
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            //动态加载所有实体映射配置实体。
            IEnumerable<Type> _entityTypeConfigurationEnumerable = Assembly.GetExecutingAssembly().GetTypes().Where(type =>
                (type.BaseType?.IsGenericType ?? false)
                    && (type.BaseType.GetGenericTypeDefinition() == typeof(EntityTypeConfigurationApply<>)));

            //逐一的从实体/聚合配置对象的集合中选出一个实体/聚合配置对象，在数据库中映射并生成相应的表.
            foreach (var item in _entityTypeConfigurationEnumerable)
            {
                IMappingConfiguration _mappingConfiguration = (IMappingConfiguration)Activator.CreateInstance(item);
                _mappingConfiguration.ApplyConfiguration(modelBuilder.Configurations);
            }
        }
        #endregion
    }
}
