﻿//程序集
using System;
using System.Linq;
using System.Collections.Generic;

//NuGet

//项目

namespace Data
{
    /// <summary>
    /// 【工作单元--类】
    /// <remarks>
    /// 摘要：
    ///    工作单元（UnitOfWork）模式： 
    ///    1、主要的作用将EF上下文实例所注册状态后的一个/多个实体实例同时持久到数据库中。
    ///    2、在提交数据时如果有一条/多条数据未能提交成功则执行回滚操作。
    ///    3、减少对数据库的调用次数，多而提高性能。
    ///    4、要确保数据库连接正确的关闭并销毁和释放EF上下文实例， 来确保EF上下文实例使用完后被显式地销毁。
    ///     因为IUnitOfWork接口继承自IDisposable接口，所以不再对IDisposable接口中的Dispose()方法再一次进行声明，
    /// 只在UnitOfWork类中对IDisposable接口中的Dispose()方法进行定义和实现。
    /// </remarks>
    /// </summary>
    public interface IUnitOfWork : IDisposable
    {
        #region 方法
        // <summary>
        /// 【设置】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <returns>
        /// 返回：
        ///     返回，获取一个指定实体类型的IQueryable实例。
        /// </returns>
        /// <remarks>
        /// 摘要：
        ///    IQueryable返回的是查询表达式，即是把Skip， Where,take 这些方法表达式的操作翻译成相应的T-SQL语句，
        /// 也就是说生成了SQL查询语句但是却还没有与数据库进行交互。
        /// 如想要获取指定实体所对应的数据库表中的所有的数据集，需要在该方法后添加：“.ToList()”。
        /// IQueryable，IEnumerable的区别：
        ///     IEnumerable<T> 泛型类在调用自己的SKip 和 Take 等扩展方法之前数据就已经加载在本地内存里了，
        ///  而IQueryable<T> 是将Skip， Where,take 这些方法表达式翻译成T-SQL语句之后再向SQL服务器发送命令，
        ///  也是延迟在我要真正显示数据的时候才执行。
        /// </remarks> 
        /// </summary>
        IQueryable<TEntity> Set<TEntity>() where TEntity : class;

        /// <summary>
        /// 【获取所有】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <returns>
        /// 返回：
        ///     返回，获取一个指定实体类型的IQueryable实例。
        /// </returns>
        /// <remarks>
        /// 摘要：
        ///    此方法主要通过一个指定实体类型实例从数据库中相应的表中获取所有的数据行，
        ///  该方法只能用于数据查询后的显示操作，不能在使用此方法获取指定实例后，再执行更新等操作，否则会产生异常。
        ///     IQueryable返回的是查询表达式，即是把Skip， Where,take 这些方法表达式的操作翻译成相应的T-SQL语句，
        /// 也就是说生成了SQL查询语句但是却还没有与数据库进行交互。
        /// 如想要获取指定实体所对应的数据库表中的所有的数据集，需要在该方法后添加：“.ToList()”。
        /// </remarks> 
        /// </summary>
        IQueryable<TEntity> GetAll<TEntity>() where TEntity : class;

        /// <summary>
        /// 【插入】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entity">一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     先将一个指定类型的实体实例先注册为新建状态后，将其提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        void Insert<TEntity>(TEntity entity) where TEntity : class;

        /// <summary>
        /// 【插入】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///     先将指定类型的实体实例集合中的每个实例先注册为新建状态后，将实体实例集合同时提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        void Insert<TEntity>(IEnumerable<TEntity> entityEnumerable) where TEntity : class;

        /// <summary>
        /// 【更新】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="oldEntity">更新前的，一个指定类型的实体实例。</param>
        /// <param name="newEntity">将要被更新的，一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     先比较更新前与将要被更新一个指定类型的实体实例中的数据异同，如果两者有不同的数据，
        /// 更新前实体实例中的数据替换为被更新实体实例中的数据，同时将数据更新后的更新前实体实例被注册为更新状态后，
        /// 将其提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        void Update<TEntity>(TEntity oldEntity, TEntity newEntity) where TEntity : class;

        /// <summary>
        /// 【更新】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="oldEntityEnumerable">更新前的，一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <param name="newEntityEnumerable">>将要被更新的，一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///    先将实体实例集合中的每个实例逐一比较更新前与将要被更新实体实例中的数据异同，如果两者有不同的数据，
        /// 更新前实体实例中的数据替换为被更新实体实例中的数据，同时将数据更新后的更新前实体实例逐一被注册为更新状态后，
        /// 将数据更新后的更新前实体实例集合同时提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        void Update<TEntity>(IEnumerable<TEntity> oldEntityEnumerable, IEnumerable<TEntity> newEntityEnumerable) where TEntity : class;

        /// <summary>
        /// 【更新】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entity">一个/多个属性所对应的数据被更新后的实体实例。</param>
        /// <param name="propertyArray">
        ///     将要被更新的，指定实体的一个/多个属性（此属性必须与数据库表中有相对应存在的字段）集合的字符串集合数组实例。
        /// </param>
        /// <remarks>
        /// 摘要：
        ///     先将一个指定类型的实体实例在一个/多个属性所对应的数据被更新后，此时实体实例的这些属性例逐一被注册为更新状态后，
        /// 将此时实体实例提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        void Update<TEntity>(TEntity entity, string[] propertyArray) where TEntity : class;

        /// <summary>
        /// 【更新】
        ///  <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <param name="propertyArray">
        ///     将要被更新的，指定实体的一个/多个属性（此属性必须与数据库表中有相对应存在的字段）集合的字符串集合数组实例。
        /// </param>
        /// <remarks>
        /// 摘要：
        ///      先将实体实例集合中的每个实例在一个/多个属性所对应的数据被更新后，此时逐一的将这些实体实例的这些属性逐一被注册为更新状态后，
        /// 将数据更新后的更新前实体实例集合同时提交并插入数据相应的表中。
        /// </remarks> 
        /// </summary>
        void Update<TEntity>(IEnumerable<TEntity> entityEnumerable, string[] propertyArray) where TEntity : class;

        /// <summary>
        /// 【删除】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entity">一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     先将一个指定类型的实体实例先注册为删除状态后，将其提交并从数据表中删除实体实例所对应的行。
        /// </remarks> 
        /// </summary>
        void Delete<TEntity>(TEntity entity) where TEntity : class;

        /// <summary>
        /// 【删除】
        /// <typeparam name="TEntity">动态的实体类型。</typeparam>
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///     先将指定类型的实体实例集合中的每个实例先注册为删除状态后，
        ///  将实体实例集合同时提交并从数据表中删除实体实例所对应的一行/多行。
        /// </remarks> 
        /// </summary>
        void Delete<TEntity>(IEnumerable<TEntity> entityEnumerable) where TEntity : class;
        #endregion
    }
}
