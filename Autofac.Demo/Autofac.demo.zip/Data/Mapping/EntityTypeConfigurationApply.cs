﻿//程序集

//NuGet
//NuGet-----EntityFramework
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;

//项目

namespace Data.Mapping
{
    /// <summary>
    /// 【实体类型配置--类】
    /// <typeparam name="TEntity">动态的实体类型。</typeparam>
    /// <remarks>
    ///     表示应用实体映射配置实例注册到DbModelBuilder实例(OnModelCreating(DbModelBuilder modelBuilder)方法中的modelBuilder实例)。
    /// </remarks>
    /// </summary>
    public class EntityTypeConfigurationApply<TEntity> : EntityTypeConfiguration<TEntity>, IMappingConfiguration where TEntity : class
    {
        #region 方法--IMappingConfiguration接口实现
        /// <summary>
        /// 【应用配置】
        /// <param name="configurationRegistrar">用于实体映射配置向DbModelBuilder注册实例。</param>
        /// <remarks>
        /// 摘要：
        ///    应用实体映射配置实例注册到DbModelBuilder实例(OnModelCreating(DbModelBuilder modelBuilder)方法中的modelBuilder实例)。
        /// </remarks> 
        /// </summary>
        public virtual void ApplyConfiguration(ConfigurationRegistrar configurationRegistrar)
        {
            configurationRegistrar.Add(this);
        }
        #endregion
    }
}
