﻿//NuGet
//NuGet-----EntityFramework
using System.Data.Entity.ModelConfiguration.Configuration;

//项目
using Models;

namespace Data.Mapping
{
    /// <summary>
    /// 【课程映射配置--类】
    /// <remarks>
    ///     表示课程映射配置类。
    /// </remarks>
    /// </summary>
    public class CourseMap : EntityTypeConfigurationApply<Course>
    {
        #region 拷贝构造方法
        /// <summary>
        /// 【拷贝构造方法】
        /// <remarks>
        /// 摘要：
        ///    对该类中的一些对象的实例，进行初始化操作。
        /// </remarks> 
        /// </summary>
        public CourseMap()
        {
            HasKey<long>(p => p.CourseID);
            Property(p => p.Name).IsRequired().HasMaxLength(100);
        }
        #endregion

        #region 方法--IMappingConfiguration接口实现
        /// <summary>
        /// 【应用配置】
        /// <param name="configurationRegistrar">用于实体映射配置向DbModelBuilder注册实例。</param>
        /// <remarks>
        /// 摘要：
        ///    应用实体映射配置注册到DbModelBuilder实例(OnModelCreating(DbModelBuilder modelBuilder)方法中的modelBuilder实例)。
        /// </remarks> 
        /// </summary>
        public override void ApplyConfiguration(ConfigurationRegistrar configurationRegistrar)
        {
            configurationRegistrar.Add(this);
        }
        #endregion
    }
}
