﻿//默认引用

//声明引用
//程序集

//NuGet
//NuGet-----EntityFramework
using System.Data.Entity.ModelConfiguration.Configuration;

//项目

namespace Data.Mapping
{
    /// <summary>
    /// 【映射配置--接口】
    /// <remarks>
    ///     表示应用实体映射配置实例注册到DbModelBuilder实例(OnModelCreating(DbModelBuilder modelBuilder)方法中的modelBuilder实例)。
    /// </remarks>
    /// </summary>
    public partial interface IMappingConfiguration
    {

        /// <summary>
        /// 【应用配置】
        /// <param name="configurationRegistrar">用于实体映射配置向DbModelBuilder注册实例。</param>
        /// <remarks>
        /// 摘要：
        ///    应用实体映射配置实例注册到DbModelBuilder实例(OnModelCreating(DbModelBuilder modelBuilder)方法中的modelBuilder实例)。
        /// </remarks> 
        /// </summary>
        void ApplyConfiguration(ConfigurationRegistrar configurationRegistrar);
    }
}
