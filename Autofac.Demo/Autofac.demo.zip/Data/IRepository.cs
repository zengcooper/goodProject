﻿//程序集
using System.Collections.Generic;

//NuGet

//项目

namespace Data
{
    /// <summary>
    /// 【动态实体的仓储--接口】
    /// <typeparam name="TEntity">动态的实体类型。</typeparam>
    /// <remarks>
    ///      将内存中指定类型的实体实例，通过方法调用EF上下文实例注册该实体实例的状态。
    /// </remarks>
    /// </summary>
    public interface IRepository<TEntity> where TEntity : class
    {
        #region 方法
        /// <summary>
        /// 【注册新建】
        /// <param name="entity">一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     将内存中一个指定类型的实体实例，通过EF上下文实例将该实体实例被注册为新建状态。
        /// </remarks> 
        /// </summary>
        void RegisterCreate(TEntity entity);

        /// <summary>
        /// 【注册新建】
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///     将实体实例集合中的每个实例，通过EF上下文实例将这些实体实例逐一的被注册为新建状态。
        /// </remarks> 
        /// </summary>
        void RegisterCreate(IEnumerable<TEntity> entityEnumerable);

        /// <summary>
        /// 【注册更新】
        /// <param name="oldEntity">更新前的，一个指定类型的实体实例。</param>
        /// <param name="newEntity">将要被更新的，一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     本方法实际上执行的是比较更新前与将要被更新实体实例中的数据异同，如果两者有不同的数据，
        /// 更新前实体实例中的数据替换为被更新实体实例中的数据，同时将数据更新后的更新前实体实例被注册为更新状态。
        /// </remarks> 
        /// </summary>
        void RegisterUpdate(TEntity oldEntity, TEntity newEntity);

        /// <summary>
        /// 【注册更新】
        /// <param name="oldEntityEnumerable">更新前的，一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <param name="newEntityEnumerable">>将要被更新的，一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///    将实体实例集合中的每个实例逐一比较更新前与将要被更新实体实例中的数据异同，如果两者有不同的数据，
        /// 更新前实体实例中的数据替换为被更新实体实例中的数据，同时将数据更新后的更新前实体实例逐一被注册为更新状态。
        /// </remarks> 
        /// </summary>
        void RegisterUpdate(IEnumerable<TEntity> oldEntityEnumerable, IEnumerable<TEntity> newEntityEnumerable);

        /// <summary>
        /// 【注册更新】
        /// <param name="entity">一个/多个属性所对应的数据被更新后的实体实例。</param>
        /// <param name="propertyArray">
        ///     将要被更新的，指定实体的一个/多个属性（此属性必须与数据库表中有相对应存在的字段）集合的字符串集合数组实例。
        /// </param>
        /// <remarks>
        /// 摘要：
        ///     通过一个指定类型的实体实例在一个/多个属性所对应的数据被更新后，此时实体实例的这些属性例逐一被注册为更新状态。
        /// </remarks> 
        /// </summary>
        void RegisterUpdate(TEntity entity, string[] propertyArray);

        /// <summary>
        /// 【注册更新】
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <param name="propertyArray">
        ///     将要被更新的，指定实体的一个/多个属性（此属性必须与数据库表中有相对应存在的字段）集合的字符串集合数组实例。
        /// </param>
        /// <remarks>
        /// 摘要：
        ///     将实体实例集合中的每个实例在一个/多个属性所对应的数据被更新后，此时逐一的将这些实体实例的这些属性逐一被注册为更新状态。
        /// </remarks> 
        /// </summary>
        void RegisterUpdate(IEnumerable<TEntity> entityEnumerable, string[] propertyArray);

        /// <summary>
        /// 【删除状态】
        /// <param name="entity">一个指定类型的实体实例。</param>
        /// <remarks>
        /// 摘要：
        ///     将内存中一个指定类型的实体实例，通过EF上下文实例将该实体实例被注册为删除状态。
        /// </remarks> 
        /// </summary>
        void RegisterDeleted(TEntity entity);

        /// <summary>
        /// 【删除状态】
        /// <param name="entityEnumerable">一个/多个指定类型实体实例集合的枚举数实例。</param>
        /// <remarks>
        /// 摘要：
        ///     将实体实例集合中的每个实例，通过EF上下文实例将这些实体实例逐一的被注册为删除状态。
        /// </remarks> 
        /// </summary>
        void RegisterDeleted(IEnumerable<TEntity> entityCollection);
        #endregion
    }
}
