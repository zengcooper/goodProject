﻿//程序集
using System.Collections.Generic;
using static System.Console;
using System.Linq;

//NuGet
//NuGet----Autofac
using Autofac;

//项目
using Models;
using Data;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
           
            //创建autofac管理注册类的容器实例。
            var builder = new ContainerBuilder();
            //注册所有实现了 IDependency 接口的类型。
            builder.RegisterType<EFContext>().As<IDBContext>().InstancePerLifetimeScope();
            builder.Register(context => new UnitOfWork(new EFContext())).As<IUnitOfWork>().InstancePerLifetimeScope();
            IContainer container = builder.Build();

            IUnitOfWork _unitOfWork = container.Resolve<IUnitOfWork>();

            Add1(_unitOfWork);
            Add30(_unitOfWork);
            WriteLine("数据添加完成！！！\n");
            List<TeacherGroup> _teacherGroupList = _unitOfWork.GetAll<TeacherGroup>().ToList();
            foreach (var item in _teacherGroupList)
            {
                WriteLine("教研组编号：{0}；教研组名称：{1}", item.TeacherGroupID, item.Name);
            }
            WriteLine("共有数据--{0}--行", _teacherGroupList.Count());



            Update1(_unitOfWork, 10);
            WriteLine("更新编号为10的行！！！\n");
            _teacherGroupList = _unitOfWork.GetAll<TeacherGroup>().ToList();
            foreach (var item in _teacherGroupList)
            {
                WriteLine("教研组编号：{0}；教研组名称：{1}", item.TeacherGroupID, item.Name);
            }
            WriteLine("共有数据--{0}--行", _teacherGroupList.Count());

            UpdateList(_unitOfWork);
            WriteLine("更新编号为3--5的行！！！\n");
            _teacherGroupList = _unitOfWork.GetAll<TeacherGroup>().ToList();
            foreach (var item in _teacherGroupList)
            {
                WriteLine("教研组编号：{0}；教研组名称：{1}", item.TeacherGroupID, item.Name);
            }
            WriteLine("共有数据--{0}--行", _teacherGroupList.Count());

            Updateproperty1(_unitOfWork, 20);
            WriteLine("属性----更新编号为20的行！！！\n");
            _teacherGroupList = _unitOfWork.GetAll<TeacherGroup>().ToList();
            foreach (var item in _teacherGroupList)
            {
                WriteLine("教研组编号：{0}；教研组名称：{1}", item.TeacherGroupID, item.Name);
            }
            WriteLine("共有数据--{0}--行", _teacherGroupList.Count());

            UpdatePropertyList(_unitOfWork);
            WriteLine("属性----更新编号为13--15的行！！！\n");
            _teacherGroupList = _unitOfWork.GetAll<TeacherGroup>().ToList();
            foreach (var item in _teacherGroupList)
            {
                WriteLine("教研组编号：{0}；教研组名称：{1}", item.TeacherGroupID, item.Name);
            }
            WriteLine("共有数据--{0}--行", _teacherGroupList.Count());



            WriteLine("下面执行的是删除操作！！！\n");
            WriteLine("删除编号为19的行！！！\n");
            Delete1(_unitOfWork, 19);
            _teacherGroupList = _unitOfWork.GetAll<TeacherGroup>().ToList();
            foreach (var item in _teacherGroupList)
            {
                WriteLine("教研组编号：{0}；教研组名称：{1}", item.TeacherGroupID, item.Name);
            }
            WriteLine("共有数据--{0}--行", _teacherGroupList.Count());

            WriteLine("删除编号从23---25的行！！！\n");
            DeleteList(_unitOfWork);
            _teacherGroupList = _unitOfWork.GetAll<TeacherGroup>().ToList();
            foreach (var item in _teacherGroupList)
            {
                WriteLine("教研组编号：{0}；教研组名称：{1}", item.TeacherGroupID, item.Name);
            }
            WriteLine("共有数据--{0}--行", _teacherGroupList.Count());

            ReadKey();
        }

        public static void Add1(IUnitOfWork unitOfWork)
        {
            TeacherGroup _model = new TeacherGroup
            {
                Name = "AutofacFramework" + "_Add1",
            };
            unitOfWork.Insert<TeacherGroup>(_model);

        }

        public static void Add30(IUnitOfWork unitOfWork)
        {
            List<TeacherGroup> _list = new List<TeacherGroup>();
            for (int i = 1; i <= 30; i++)
            {
                TeacherGroup _model = new TeacherGroup
                {
                    Name = "AutofacFramework" + "_Add30" + "_" + i,
                };
                _list.Add(_model);
            }

            unitOfWork.Insert<TeacherGroup>(_list);

        }

        public static void Update1(IUnitOfWork unitOfWork, long teacherGroupId = 1)
        {
            TeacherGroup _modelOld = unitOfWork.Set<TeacherGroup>().FirstOrDefault(p => p.TeacherGroupID == teacherGroupId);
            TeacherGroup _moleNew = _modelOld;
            _moleNew.Name = _modelOld.Name + "_Update" + "_" + _modelOld.TeacherGroupID;
            unitOfWork.Update<TeacherGroup>(_modelOld, _moleNew);
        }

        public static void UpdateList(IUnitOfWork unitOfWork, long min = 3, long max = 5)
        {

            List<TeacherGroup> _listOld = unitOfWork.Set<TeacherGroup>().Where(p => p.TeacherGroupID >= min && p.TeacherGroupID <= max).ToList();
            List<TeacherGroup> _listNew = new List<TeacherGroup>();

            foreach (TeacherGroup item in _listOld)
            {
                TeacherGroup _moleNew = item;
                _moleNew.Name = item.Name + "_UpdateList" + "_" + item.TeacherGroupID;
                _listNew.Add(_moleNew);
            }

            unitOfWork.Update<TeacherGroup>(_listOld, _listNew);
        }

        public static void Updateproperty1(IUnitOfWork unitOfWork, long teacherGroupId = 1)
        {
            TeacherGroup _model = unitOfWork.Set<TeacherGroup>().FirstOrDefault(p => p.TeacherGroupID == teacherGroupId);
            _model.Name = _model.Name + "_Updateproperty1" + "_" + _model.TeacherGroupID;
            unitOfWork.Update<TeacherGroup>(_model, new string[] { "Name" });
        }

        public static void UpdatePropertyList(IUnitOfWork unitOfWork, long min = 13, long max = 15)
        {
            List<TeacherGroup> _modelList = unitOfWork.Set<TeacherGroup>().Where(p => p.TeacherGroupID >= min && p.TeacherGroupID <= max).ToList();
            List<TeacherGroup> _modelListNew = new List<TeacherGroup>();
            foreach (TeacherGroup item in _modelList)
            {

                item.Name = item.Name + "_ UpdatePropertyList" + "_" + item.TeacherGroupID;
                _modelListNew.Add(item);
            }
            unitOfWork.Update<TeacherGroup>(_modelListNew, new string[] { "Name" });
        }

        public static void Delete1(IUnitOfWork unitOfWork, long teacherGroupId = 1)
        {
            TeacherGroup _model = unitOfWork.Set<TeacherGroup>().FirstOrDefault(p => p.TeacherGroupID == teacherGroupId);
            unitOfWork.Delete<TeacherGroup>(_model);
        }

        public static void DeleteList(IUnitOfWork unitOfWork, long min = 23, long max = 25)
        {
            List<TeacherGroup> _modelList = unitOfWork.Set<TeacherGroup>().Where(p => p.TeacherGroupID >= min && p.TeacherGroupID <= max).ToList();
            unitOfWork.Delete<TeacherGroup>(_modelList);
        }
    }
}
