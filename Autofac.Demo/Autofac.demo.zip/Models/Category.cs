﻿//程序集
using System.Collections.Generic;

//NuGet

//项目

namespace Models
{
    /// <summary>
    /// 【班级--类】
    /// <remarks>
    /// 摘要：
    ///    表示班级实体类。
    /// </remarks>
    /// </summary>
    public class Category
    {
        #region 属性
        /// <summary>
        /// 【班级编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置班级实体的班级编号。
        /// </remarks>
        /// </summary>
        public int CategoryID { get; set; }

        /// <summary>
        /// 【年级编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置班级实体的年级编号。
        /// </remarks>
        /// </summary>
        public int GradeID { get; set; }

        /// <summary>
        /// 【名称】
        /// <remarks>
        /// 摘要：
        ///    获取/设置班级实体的班级名称。
        /// </remarks>
        /// </summary>
        public string Name { get; set; }
        #endregion

        #region 属性--映射
        /// <summary>
        /// 【年级实体单一实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置班级实体的年级实体单一实例，此属性用于显示定义并实现年级--班级之间所形成的1--n映射，
        /// 同时还表现在调用时班级实体实例与年级实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual Grade GradeSingle { get; set; }

        /// <summary>
        /// 【学生实体集合实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置班级实体的学生实体集合实例，此属性用于显示定义并实现班级--学生之间所形成的1--n映射，
        /// 同时还表现在调用时班级实体实例与学生实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual ICollection<Student> StudentCollection { get; set; }
        #endregion
    }
}
