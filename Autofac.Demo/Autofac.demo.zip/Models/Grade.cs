﻿//程序集
using System.Collections.Generic;

//NuGet

//项目

namespace Models
{
    /// <summary>
    /// 【年级--类】
    /// <remarks>
    /// 摘要：
    ///    表年级实体类。
    /// </remarks>
    /// </summary>
    public class Grade
    {
        #region 属性
        /// <summary>
        /// 【年级编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置年级实体的年级编号。
        /// </remarks>
        /// </summary>
        public int GradeID{ get; set; }

        /// <summary>
        /// 【名称】
        /// <remarks>
        /// 摘要：
        ///    获取/设置年级实体的年级名称。
        /// </remarks>
        /// </summary>
        public string Name{ get; set; }
        #endregion

        #region 属性--映射
        /// <summary>
        /// 【年级所在专业实体集合实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置年级实体的年级所在专业实体集合实例，此属性用于显示定义并实现年级--专业之间所形成的n--n映射，
        /// 同时还表现在调用时年级实体实例与专业实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual ICollection<GradeInSpecialty> GradeInSpecialtyCollection { get; set; }

        /// <summary>
        /// 【班级实体集合实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置年级实体的班级实体集合实例，此属性用于显示定义并实现年级--班级之间所形成的1--n映射，
        /// 同时还表现在调用时年级实体实例与班级实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual ICollection<Category> CategoryCollection { get; set; }
        #endregion
    }
}
