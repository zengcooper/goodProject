﻿//程序集
using System.Collections.Generic;

//NuGet

//项目

namespace Models
{
    /// <summary>
    /// 【教师--类】
    /// <remarks>
    /// 摘要：
    ///    表示教师实体类。
    /// </remarks>
    /// </summary>
    public class Teacher
    {
        #region 属性
        /// <summary>
        /// 【教师编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置教师实体的教师编号。
        /// </remarks>
        /// </summary>
        public int TeacherID { get; set; }

        /// <summary>
        /// 【教师编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置教师实体的教研组编号。
        /// </remarks>
        /// </summary>
        public int TeacherGroupID { get; set; }

        /// <summary>
        /// 【姓名】
        /// <remarks>
        /// 摘要：
        ///    获取/设置教师实体的教师姓名。
        /// </remarks>
        /// </summary>
        public string Name { get; set; }
        #endregion

        #region 属性--映射
        /// <summary>
        /// 【教研组实体单一实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置教师实体的教研组实体单一实例，此属性用于显示定义并实现教研组--教师之间所形成的1--n映射，
        /// 同时还表现在调用时教师实体实例与教研组实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual TeacherGroup TeacherGroupSingle { get; set; }

        /// <summary>
        /// 【教师所教课程实体集合实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置教师实体的教师所教课程实体集合实例，此属性用于显示定义并实现教师--课程之间所形成的n--n映射，
        /// 同时还表现在调用时教师实体实例与课程实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual ICollection<TeacherInCourse> TeacherInCourseCollection { get; set; }
        #endregion
    }
}
