﻿//声明引用
//程序集
using System.Collections.Generic;

//NuGet

//项目


namespace Models
{
    /// <summary>
    /// 【教研组--类】
    /// <remarks>
    /// 摘要：
    ///    表示教研组实体类。
    /// </remarks>
    /// </summary>
    public class TeacherGroup
    {
        #region 属性
        /// <summary>
        /// 【教研组编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置教研组实体的教研组编号。
        /// </remarks>
        /// </summary>

        ///<summary>
        ///教研组编号：主键
        ///</summary>
        public int TeacherGroupID { get; set; }

        /// <summary>
        /// 【名称】
        /// <remarks>
        /// 摘要：
        ///    获取/设置教研组实体的教研组名称。
        /// </remarks>
        /// </summary>
        public string Name { get; set; }
        #endregion

        #region 属性--映射
        /// <summary>
        /// 【教师实体集合实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置教研组实体的教师实体集合实例，此属性用于显示定义并实现教研组--教师之间所形成的1--n映射，
        /// 同时还表现在调用时教研组实体实例与教师实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        //public virtual ICollection<Teacher> TeacherCollection { get; set; }
        #endregion
    }
}
