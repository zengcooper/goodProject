﻿namespace Models
{
    /// <summary>
    /// 【成绩--类】
    /// <remarks>
    /// 摘要：
    ///    表成绩实体类。
    /// </remarks>
    /// </summary>
    public class Score
    {
        #region 属性
        /// <summary>
        /// 【成绩编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置成绩实体的成绩编号。
        /// </remarks>
        /// </summary>
        public int ScoreID { get; set; }

        /// <summary>
        /// 【学生编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置成绩实体的学生编号。
        /// </remarks>
        /// </summary>
        public int StudentID { get; set; }

        /// <summary>
        /// 【教师编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置成绩实体的教师编号。
        /// </remarks>
        /// </summary>
        public int TeacherID { get; set; }

        /// <summary>
        /// 【课程编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置成绩实体的课程编号。
        /// </remarks>
        /// </summary>
        public int CourseID { get; set; }

        /// <summary>
        /// 【名称】
        /// <remarks>
        /// 摘要：
        ///    获取/设置成绩实体的成绩名称。
        /// </remarks>
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 【分数】
        /// <remarks>
        /// 摘要：
        ///    获取/设置成绩实体的成绩分数。
        /// </remarks>
        /// </summary>
        public int? Credit { get; set; }

        /// <summary>
        /// 【备注】
        /// <remarks>
        /// 摘要：
        ///    获取/设置成绩实体的备注。
        /// </remarks>
        /// </summary>
        public string Remark{ get; set; }
        #endregion

        #region 属性--映射
        /// <summary>
        /// 【学生实体单一实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置成绩实体的学生实体单一实例，此属性用于显示定义并实现学生--成绩之间所形成的1--n映射，
        /// 同时还表现在调用时成绩实体实例与成绩实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual Student StudentSingle { get; set; }
        #endregion
    }
}
