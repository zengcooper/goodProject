﻿//程序集
using System.Collections.Generic;

//NuGet

//项
namespace Models
{
    /// <summary>
    /// 【学生--类】
    /// <remarks>
    /// 摘要：
    ///    表学生实体类。
    /// </remarks>
    /// </summary>
    public class Student
    {
        #region 属性
        /// <summary>
        /// 【学生编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置学生实体的学生编号。
        /// </remarks>
        /// </summary>
        public int StudentID{ get; set; }

        /// <summary>
        /// 【班级编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置学生实体的班级编号。
        /// </remarks>
        /// </summary>
        public int CategoryID { get; set; }

        /// <summary>
        /// 【学号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置学生实体的学号。
        /// </remarks>
        /// </summary>
        public string StudentCode { get; set; }

        /// <summary>
        /// 【姓名】
        /// <remarks>
        /// 摘要：
        ///    获取/设置学生实体的学生姓名。
        /// </remarks>
        /// </summary>
        public string Name { get; set; }
        #endregion

        #region 属性--映射
        /// <summary>
        /// 【班级实体单一实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置学生实体的班级实体单一实例，此属性用于显示定义并实现学生--班级之间所形成的1--n映射，
        /// 同时还表现在调用时班级实体实例与学生实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual Category CategorySingle { get; set; }

        /// <summary>
        /// 【成绩实体集合实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置学生实体的成绩实体集合实例，此属性用于显示定义并实现学生--成绩之间所形成的1--n映射，
        /// 同时还表现在调用时学生实体实例与成绩实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual ICollection<Score> ScoreCollection { get; set; }

        /// <summary>
        /// 【学生所学课程实体集合实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置学生实体的学生所学课程实体集合实例，此属性用于显示定义并实现学生--课程之间所形成的n--n映射，
        /// 同时还表现在调用时学生实体实例与课程实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual ICollection<StudentInCourse> StudentInCourseCollection { get; set; }
        #endregion
    }
}
