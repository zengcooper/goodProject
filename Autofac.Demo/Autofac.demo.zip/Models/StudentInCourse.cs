﻿namespace Models
{
    /// <summary>
    /// 【学生所学课程--类】
    /// <remarks>
    /// 摘要：
    ///    表示学生所学课程实体类。
    /// </remarks>
    /// </summary>
    public class StudentInCourse
    {
        #region 属性
        /// <summary>
        /// 【学生编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置学生所学课程实体的学生编号。
        /// </remarks>
        /// </summary>
        public int StudentID { get; set; }

        /// <summary>
        /// 【课程编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置学生所学课程实体的课程编号。
        /// </remarks>
        /// </summary>
        public int CourseID { get; set; }
        #endregion

        #region 属性--映射
        /// <summary>
        /// 【教师实体单一实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置学生所学课程实体的学生实体单一实例，此属性用于显示定义并实现学生--课程之间所形成的n--n映射，
        /// 同时还表现在调用时学生实体实例与课程实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual Student StudentSingle { get; set; }

        /// <summary>
        /// 【课实体单一实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置教师所教课程实体的课实体单一实例，此属性用于显示定义并实现教师--课程之间所形成的n--n映射，
        /// 同时还表现在调用时教师实体实例与课程实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual Course CourseSingle { get; set; }
        #endregion
    }
}
