﻿//程序集
using System.Collections.Generic;

//NuGet

//项目

namespace Models
{
    /// <summary>
    /// 【课程--类】
    /// <remarks>
    /// 摘要：
    ///    表示课程实体类。
    /// </remarks>
    /// </summary>
    public class Course
    {
        #region 属性
        /// <summary>
        /// 【课程编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置课程实体的课程编号。
        /// </remarks>
        /// </summary>
        public int CourseID { get; set; }

        /// <summary>
        /// 【名称】
        /// <remarks>
        /// 摘要：
        ///    获取/设置课程实体的课程名称。
        /// </remarks>
        /// </summary>
        public string Name { get; set; }
        #endregion

        #region 属性--映射
        /// <summary>
        /// 【学生所学课程实体集合实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置课程实体的学生所学课程实体集合实例，此属性用于显示定义并实现学生--课程之间所形成的n--n映射，
        /// 同时还表现在调用时学生实体实例与课程实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual ICollection<StudentInCourse> StudentInCourseCollection { get; set; }

        /// <summary>
        /// 【教师所教课程实体集合实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置课程实体的教师所教课程实体集合实例，此属性用于显示定义并实现教师--课程之间所形成的n--n映射，
        /// 同时还表现在调用时教师实体实例与课程实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual ICollection<TeacherInCourse> TeacherInCourseCollection { get; set; }
        #endregion
    }
}
