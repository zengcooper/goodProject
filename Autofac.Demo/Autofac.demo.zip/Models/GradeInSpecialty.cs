﻿namespace Models
{
    /// <summary>
    /// 【年级所在专业--类】
    /// <remarks>
    /// 摘要：
    ///    表示年级所在专业实体类。
    /// </remarks>
    /// </summary>
    public class GradeInSpecialty
    {
        #region 属性
        /// <summary>
        /// 【年级编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置年级所在专业实体的年级编号。
        /// </remarks>
        /// </summary>
        public int GradeID { get; set; }

        /// <summary>
        /// 【专业编号】
        /// <remarks>
        /// 摘要：
        ///    获取/设置年级所在专业实体的专业编号。
        /// </remarks>
        /// </summary>
        public int SpecialtyID { get; set; }
        #endregion

        #region 属性--映射
        /// <summary>
        /// 【年级实体单一实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置年级所在专业实体的年级实体单一实例，此属性用于显示定义并实现年级--专业之间所形成的n--n映射，
        /// 同时还表现在调用时年级实体实例与专业实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual Grade GradeSingle { get; set; }

        /// <summary>
        /// 【专业实体单一实例】
        /// <remarks>
        /// 摘要：
        ///    获取/设置年级所在专业实体的专业实体单一实例，此属性用于显示定义并实现年级--专业之间所形成的n--n映射，
        /// 同时还表现在调用时年级实体实例与专业实体实例之间在内存中构建出相同的实例映射结构，以及在相应的数据库中和表中形成同样的映射关系。
        /// </remarks>
        /// </summary>
        public virtual Specialty SpecialtySingle { get; set; }
        #endregion
    }
}
