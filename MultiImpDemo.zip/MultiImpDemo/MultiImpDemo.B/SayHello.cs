﻿/**
*┌──────────────────────────────────────────────────────────────┐
*│　描    述：                                                    
*│　作    者：yilezhu                                             
*│　版    本：1.0                                                 
*│　创建时间：2019/1/7 17:41:45                             
*└──────────────────────────────────────────────────────────────┘
*┌──────────────────────────────────────────────────────────────┐
*│　命名空间： MultiImpDemo.B                                   
*│　类    名： SayHello                                      
*└──────────────────────────────────────────────────────────────┘
*/
using MultiImpDemo.I;
using System;
using System.Collections.Generic;
using System.Text;

namespace MultiImpDemo.B
{
    public class SayHello:ISayHello
    {
        public string ImplementAssemblyName => "MultiImpDemo.B";

        public string Talk()
        {
            return "Talk from B.SayHello";
        }
    }
}
