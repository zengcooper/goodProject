﻿/**
*┌──────────────────────────────────────────────────────────────┐
*│　描    述：                                                    
*│　作    者：yilezhu                                             
*│　版    本：1.0                                                 
*│　创建时间：2019/1/7 17:41:33                             
*└──────────────────────────────────────────────────────────────┘
*┌──────────────────────────────────────────────────────────────┐
*│　命名空间： MultiImpDemo.A                                   
*│　类    名： SayHello                                      
*└──────────────────────────────────────────────────────────────┘
*/
using MultiImpDemo.I;
using System;
using System.Collections.Generic;
using System.Text;

namespace MultiImpDemo.A
{
    public class SayHello : ISayHello
    {
        public string ImplementAssemblyName => "MultiImpDemo.A";

        public string Talk()
        {
            return "Talk from A.SayHello";
        }
    }
}
