﻿/**
*┌──────────────────────────────────────────────────────────────┐
*│　描    述：                                                    
*│　作    者：yilezhu                                             
*│　版    本：1.0                                                 
*│　创建时间：2019/1/7 17:41:03                             
*└──────────────────────────────────────────────────────────────┘
*┌──────────────────────────────────────────────────────────────┐
*│　命名空间： MultiImpDemo.I                                   
*│　接口名称： ISayHello                                      
*└──────────────────────────────────────────────────────────────┘
*/
using System;
using System.Collections.Generic;
using System.Text;

namespace MultiImpDemo.I
{
    public interface ISayHello
    {
        string ImplementAssemblyName { get; }
        string Talk();
    }
}
