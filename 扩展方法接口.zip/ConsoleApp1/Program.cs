﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            MyInterface mm = new MyClass2();
            mm.MyTest002();
            Console.WriteLine("***********");
            ((MyClass2)mm).MyTest02();
            Console.ReadLine();
        }
    }
    interface MyInterface
    {
        void Test01();
    }
    public class MyClass : MyInterface
    {
        public void Test01()
        {
            Console.WriteLine("Test01");
        }
    }
    public class MyClass2 : MyInterface
    {
        public void Test01()
        {
            Console.WriteLine("Test02");
        }
        public void MyTest02()
        {
            Console.WriteLine("MyTest002");
        }
    }
    static class MyExtensionMethods
    {
        public static void MyTest002(this MyInterface ii)
        {
            ii.Test01();
        }
    }
}
